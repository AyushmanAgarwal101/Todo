package com.example.todo;

import android.annotation.SuppressLint;
import android.content.DialogInterface;

public interface MainActivity2 {
    @SuppressLint("NotifyDataSetChanged")
    void handleDialogClose(DialogInterface dialog);
}
